//Written by Joe
//202 Prog. 1

public class HelloWorld {

	public static void main(String[] args) {
		
		//displays "hello world"  to console
		System.out.println(" Hello World!!!  ");

	}// end main

}//end class
